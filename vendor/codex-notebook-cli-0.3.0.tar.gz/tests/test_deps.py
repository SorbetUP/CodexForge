from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

import nbformat

from cnb.deps import analyze_source, build_graph
from cnb import cli


class DependencyAnalysisTests(unittest.TestCase):
    def test_symbol_graph_uses_latest_writer(self):
        nb = nbformat.v4.new_notebook(cells=[
            nbformat.v4.new_code_cell("a = 10"),
            nbformat.v4.new_code_cell("b = a + 1"),
            nbformat.v4.new_code_cell("a = 99"),
            nbformat.v4.new_code_cell("c = a + b"),
        ])
        g = build_graph(nb.cells)
        self.assertEqual(g.dependencies[1], {0: {"a"}})
        self.assertEqual(g.dependencies[3], {1: {"b"}, 2: {"a"}})

    def test_common_mutations_become_producers(self):
        info = analyze_source('df["x"] = 1\nmodel.fit(X, y)\nitems.append(3)')
        self.assertTrue({"df", "model", "items"} <= info.mutations)
        self.assertTrue({"df", "model", "items", "X", "y"} <= info.reads)

    def test_function_global_is_tracked_conservatively(self):
        nb = nbformat.v4.new_notebook(cells=[
            nbformat.v4.new_code_cell("df = [1, 2, 3]"),
            nbformat.v4.new_code_cell("def nrows():\n    return len(df)"),
            nbformat.v4.new_code_cell("n = nrows()"),
        ])
        g = build_graph(nb.cells)
        self.assertEqual(g.dependencies[1], {0: {"df"}})
        self.assertEqual(g.dependencies[2], {1: {"nrows"}})


class LiveKernelPlanningTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_state = os.environ.get("XDG_STATE_HOME")
        os.environ["XDG_STATE_HOME"] = str(Path(self.tmp.name) / "state")
        self.nb_path = Path(self.tmp.name) / "plan.ipynb"
        nb = nbformat.v4.new_notebook(cells=[
            nbformat.v4.new_code_cell("a = 10"),
            nbformat.v4.new_code_cell("b = a + 1"),
            nbformat.v4.new_code_cell("c = b * 2"),
            nbformat.v4.new_code_cell("a = 99"),
            nbformat.v4.new_code_cell("d = c + 1"),
            nbformat.v4.new_code_cell("e = a + d"),
        ])
        nbformat.write(nb, self.nb_path)
        cli.start(self.nb_path)
        for i in range(6):
            cli.run_cell(self.nb_path, i, 30)

    def tearDown(self):
        try:
            cli.stop(self.nb_path)
        except Exception:
            pass
        if self.old_state is None:
            os.environ.pop("XDG_STATE_HOME", None)
        else:
            os.environ["XDG_STATE_HOME"] = self.old_state
        self.tmp.cleanup()

    def test_out_of_order_writer_is_restored(self):
        plan, warnings = cli._plan_for_target(self.nb_path, 1)
        self.assertEqual(plan, [0, 1])
        self.assertTrue(any("live writer differs for a" in w for w in warnings))

    def test_modified_upstream_yields_minimal_replay(self):
        nb = cli.load_nb(self.nb_path)
        nb.cells[0].source = "a = 20"
        nb.cells[0].outputs = []
        nb.cells[0].execution_count = None
        cli.save_nb(self.nb_path, nb)
        plan, _ = cli._plan_for_target(self.nb_path, 5)
        self.assertEqual(plan, [0, 1, 2, 3, 4, 5])

    def test_ephemeral_shadow_only_restores_needed_writer(self):
        code = "a = 777"
        _, _, ok = cli.run_code(self.nb_path, code, 30, quiet=True)
        cli._record_ephemeral_execution(self.nb_path, code, ok)
        plan, _ = cli._plan_for_target(self.nb_path, 5)
        self.assertEqual(plan, [3, 5])


if __name__ == "__main__":
    unittest.main()
