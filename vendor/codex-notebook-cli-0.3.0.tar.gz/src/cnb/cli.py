from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from queue import Empty
from typing import Any

import nbformat
from jupyter_client import BlockingKernelClient

from .deps import NotebookGraph, analyze_source, build_graph, source_hash


_LOCAL_KERNEL_PROCS: dict[int, subprocess.Popen] = {}


def _state_root() -> Path:
    base = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state"))
    root = base / "codex-notebook-cli"
    root.mkdir(parents=True, exist_ok=True)
    (root / "sessions").mkdir(exist_ok=True)
    (root / "kernels").mkdir(exist_ok=True)
    (root / "logs").mkdir(exist_ok=True)
    return root


def _nb_path(value: str) -> Path:
    return Path(value).expanduser().resolve()


def _key(path: Path) -> str:
    return hashlib.sha256(str(path).encode()).hexdigest()[:16]


def _paths(path: Path) -> tuple[Path, Path, Path]:
    root = _state_root()
    key = _key(path)
    return (
        root / "sessions" / f"{key}.json",
        root / "kernels" / f"kernel-{key}.json",
        root / "logs" / f"kernel-{key}.log",
    )


def _normalize_session(session: dict[str, Any]) -> dict[str, Any]:
    session.setdefault("event_seq", 0)
    session.setdefault("cell_state", {})
    session.setdefault("events", [])
    session.setdefault("ephemeral_writes", {})
    return session


def _load_session(path: Path) -> dict[str, Any]:
    session_file, _, _ = _paths(path)
    if not session_file.exists():
        raise SystemExit(f"No active session for {path}. Run: cnb start {path}")
    return _normalize_session(json.loads(session_file.read_text()))


def _try_load_session(path: Path) -> dict[str, Any] | None:
    session_file, _, _ = _paths(path)
    if not session_file.exists():
        return None
    return _normalize_session(json.loads(session_file.read_text()))


def _save_session(path: Path, session: dict[str, Any]) -> None:
    session_file, _, _ = _paths(path)
    session_file.write_text(json.dumps(session, indent=2, ensure_ascii=False))


def _next_seq(session: dict[str, Any]) -> int:
    seq = int(session.get("event_seq", 0)) + 1
    session["event_seq"] = seq
    return seq


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def _client(connection_file: Path, ready_timeout: float = 15.0) -> BlockingKernelClient:
    kc = BlockingKernelClient()
    kc.load_connection_file(str(connection_file))
    kc.start_channels()
    kc.wait_for_ready(timeout=ready_timeout)
    return kc


def _ensure_notebook(path: Path) -> None:
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    nbformat.write(nbformat.v4.new_notebook(), path)


def _python_has_ipykernel(executable: str) -> bool:
    try:
        result = subprocess.run(
            [executable, "-c", "import ipykernel"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _project_python_candidates(path: Path) -> list[str]:
    candidates: list[str] = []
    env_python = os.environ.get("CNB_KERNEL_PYTHON")
    if env_python:
        candidates.append(env_python)

    active_venv = os.environ.get("VIRTUAL_ENV")
    if active_venv:
        candidates.extend([
            str(Path(active_venv) / "bin" / "python"),
            str(Path(active_venv) / "Scripts" / "python.exe"),
        ])

    current = path.parent
    for directory in [current, *current.parents]:
        for rel in (Path(".venv/bin/python"), Path("venv/bin/python"), Path(".venv/Scripts/python.exe"), Path("venv/Scripts/python.exe")):
            candidates.append(str(directory / rel))
        # Do not walk beyond the user's home when the notebook lives underneath it.
        if directory == Path.home():
            break

    shell_python = shutil.which("python3") or shutil.which("python")
    if shell_python:
        candidates.append(shell_python)
    candidates.append(sys.executable)

    out: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        expanded = str(Path(candidate).expanduser()) if os.sep in candidate else candidate
        resolved = shutil.which(expanded) if os.sep not in expanded else expanded
        if not resolved:
            continue
        resolved = str(Path(resolved).resolve())
        if resolved not in seen:
            seen.add(resolved)
            out.append(resolved)
    return out


def _resolve_kernel_python(path: Path, requested: str | None = None) -> str:
    if requested:
        requested_path = Path(requested).expanduser()
        executable = shutil.which(str(requested_path)) if os.sep not in str(requested_path) else str(requested_path)
        if not executable or not Path(executable).exists():
            raise SystemExit(f"Kernel Python not found: {requested}")
        executable = str(Path(executable).resolve())
        if not _python_has_ipykernel(executable):
            raise SystemExit(
                f"Kernel Python does not provide ipykernel: {executable}. "
                f"Install it in that environment with: {executable} -m pip install ipykernel"
            )
        return executable

    for executable in _project_python_candidates(path):
        if Path(executable).exists() and _python_has_ipykernel(executable):
            return executable

    raise SystemExit(
        "No usable Python with ipykernel found. Activate the project environment, set "
        "CNB_KERNEL_PYTHON, or run: cnb start NOTEBOOK --python /path/to/python"
    )


def start(path: Path, kernel_python: str | None = None) -> None:
    _ensure_notebook(path)
    session_file, connection_file, log_file = _paths(path)

    if session_file.exists():
        old = _normalize_session(json.loads(session_file.read_text()))
        pid = int(old.get("pid", -1))
        if _pid_alive(pid) and connection_file.exists():
            try:
                kc = _client(connection_file, 2.0)
                kc.stop_channels()
                _save_session(path, old)
                print(f"already-running pid={pid} notebook={path}")
                return
            except Exception:
                pass

    connection_file.unlink(missing_ok=True)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    log = open(log_file, "ab", buffering=0)
    selected_python = _resolve_kernel_python(path, kernel_python)
    proc = subprocess.Popen(
        [selected_python, "-m", "ipykernel_launcher", "-f", str(connection_file)],
        cwd=str(path.parent),
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        close_fds=True,
    )
    log.close()
    _LOCAL_KERNEL_PROCS[proc.pid] = proc

    session = _normalize_session({
        "notebook": str(path),
        "pid": proc.pid,
        "connection_file": str(connection_file),
        "log_file": str(log_file),
        "cwd": str(path.parent),
        "python": selected_python,
        "started_at": time.time(),
        "kernel_epoch": uuid.uuid4().hex,
    })
    session_file.write_text(json.dumps(session, indent=2))

    deadline = time.time() + 20
    last_error: Exception | None = None
    while time.time() < deadline:
        if proc.poll() is not None:
            raise SystemExit(f"Kernel exited early with code {proc.returncode}. Log: {log_file}")
        if connection_file.exists():
            try:
                kc = _client(connection_file, 1.0)
                kc.stop_channels()
                print(f"started pid={proc.pid} notebook={path}")
                return
            except Exception as exc:
                last_error = exc
        time.sleep(0.1)
    raise SystemExit(f"Kernel did not become ready. Log: {log_file}. Last error: {last_error}")


def stop(path: Path) -> None:
    session_file, connection_file, _ = _paths(path)
    session = _load_session(path)
    pid = int(session["pid"])
    try:
        if connection_file.exists():
            kc = _client(connection_file, 2.0)
            kc.shutdown(restart=False)
            kc.stop_channels()
    except Exception:
        pass

    deadline = time.time() + 3
    while _pid_alive(pid) and time.time() < deadline:
        time.sleep(0.1)
    if _pid_alive(pid):
        try:
            os.killpg(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass

    proc_obj = _LOCAL_KERNEL_PROCS.pop(pid, None)
    if proc_obj is not None:
        try:
            proc_obj.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            proc_obj.poll()

    session_file.unlink(missing_ok=True)
    connection_file.unlink(missing_ok=True)
    print(f"stopped notebook={path}")


def status(path: Path) -> None:
    session_file, connection_file, log_file = _paths(path)
    if not session_file.exists():
        print("stopped")
        return
    session = _normalize_session(json.loads(session_file.read_text()))
    pid = int(session.get("pid", -1))
    alive = _pid_alive(pid)
    ready = False
    if alive and connection_file.exists():
        try:
            kc = _client(connection_file, 1.0)
            ready = True
            kc.stop_channels()
        except Exception:
            ready = False
    print(json.dumps({
        "alive": alive,
        "ready": ready,
        "pid": pid,
        "notebook": str(path),
        "log": str(log_file),
        "kernel_epoch": session.get("kernel_epoch"),
        "event_seq": session.get("event_seq", 0),
    }))


def _execute(path: Path, code: str, timeout: float = 3600.0) -> tuple[list[Any], int | None, bool]:
    session = _load_session(path)
    pid = int(session["pid"])
    connection_file = Path(session["connection_file"])
    if not _pid_alive(pid):
        raise SystemExit(f"Kernel pid {pid} is not alive. Run: cnb start {path}")

    kc = _client(connection_file)
    msg_id = kc.execute(code, store_history=True, allow_stdin=False, stop_on_error=True)
    outputs: list[Any] = []
    execution_count: int | None = None
    ok = True
    deadline = time.time() + timeout

    try:
        while True:
            remaining = max(0.01, deadline - time.time())
            if remaining <= 0:
                raise TimeoutError(f"Execution exceeded {timeout}s")
            try:
                msg = kc.get_iopub_msg(timeout=min(1.0, remaining))
            except Empty:
                continue
            if msg.get("parent_header", {}).get("msg_id") != msg_id:
                continue
            msg_type = msg["header"]["msg_type"]
            content = msg["content"]

            if msg_type == "execute_input":
                execution_count = content.get("execution_count")
            elif msg_type == "stream":
                outputs.append(nbformat.v4.new_output(
                    "stream", name=content.get("name", "stdout"), text=content.get("text", "")
                ))
            elif msg_type in ("display_data", "execute_result"):
                kwargs = {
                    "data": content.get("data", {}),
                    "metadata": content.get("metadata", {}),
                }
                if msg_type == "execute_result":
                    kwargs["execution_count"] = content.get("execution_count")
                    if execution_count is None:
                        execution_count = content.get("execution_count")
                outputs.append(nbformat.v4.new_output(msg_type, **kwargs))
            elif msg_type == "error":
                ok = False
                outputs.append(nbformat.v4.new_output(
                    "error",
                    ename=content.get("ename", "Error"),
                    evalue=content.get("evalue", ""),
                    traceback=content.get("traceback", []),
                ))
            elif msg_type == "clear_output":
                outputs.clear()
            elif msg_type == "status" and content.get("execution_state") == "idle":
                break
    finally:
        kc.stop_channels()

    return outputs, execution_count, ok


def _print_output(output: Any) -> None:
    typ = output.output_type
    if typ == "stream":
        print(output.text, end="" if output.text.endswith("\n") else "\n")
    elif typ == "error":
        tb = output.get("traceback", [])
        if tb:
            print("\n".join(tb), file=sys.stderr)
        else:
            print(f"{output.ename}: {output.evalue}", file=sys.stderr)
    elif typ in ("execute_result", "display_data"):
        data = output.get("data", {})
        if "text/plain" in data:
            print(data["text/plain"])
        elif data:
            print(json.dumps(data, ensure_ascii=False, default=str))


def run_code(path: Path, code: str, timeout: float, quiet: bool = False) -> tuple[list[Any], int | None, bool]:
    outputs, execution_count, ok = _execute(path, code, timeout)
    if not quiet:
        for output in outputs:
            _print_output(output)
    return outputs, execution_count, ok


def _ensure_cell_ids(nb) -> bool:
    changed = False
    seen: set[str] = set()
    for cell in nb.cells:
        cell_id = cell.get("id")
        if not cell_id or cell_id in seen:
            cell["id"] = uuid.uuid4().hex[:12]
            changed = True
        seen.add(cell["id"])
    return changed


def load_nb(path: Path):
    _ensure_notebook(path)
    nb = nbformat.read(path, as_version=4)
    if _ensure_cell_ids(nb):
        nbformat.write(nb, path)
    return nb


def save_nb(path: Path, nb) -> None:
    _ensure_cell_ids(nb)
    nbformat.write(nb, path)


def _cell_id(cell) -> str:
    return str(cell["id"])


def _record_cell_execution(path: Path, cell, index: int, ok: bool) -> None:
    session = _load_session(path)
    seq = _next_seq(session)
    info = analyze_source(cell.get("source", ""))
    cid = _cell_id(cell)
    producers = sorted(info.producers)
    record = {
        "seq": seq,
        "source_hash": source_hash(cell.get("source", "")),
        "ok": ok,
        "index_at_run": index,
        "executed_at": time.time(),
        "writes": sorted(info.writes),
        "mutations": sorted(info.mutations),
        "producers": producers,
    }
    session["cell_state"][cid] = record
    session["events"].append({
        "seq": seq,
        "kind": "cell",
        "cell_id": cid,
        "index_at_run": index,
        "source_hash": record["source_hash"],
        "ok": ok,
        "producers": producers,
    })
    # Bound state growth. 5000 executions is already far beyond a normal
    # exploratory session, while preserving enough history for diagnostics.
    session["events"] = session["events"][-5000:]
    _save_session(path, session)


def _record_ephemeral_execution(path: Path, code: str, ok: bool) -> None:
    info = analyze_source(code)
    if not info.producers:
        return
    session = _load_session(path)
    seq = _next_seq(session)
    event = {
        "seq": seq,
        "kind": "exec",
        "source_hash": source_hash(code),
        "ok": ok,
        "producers": sorted(info.producers),
    }
    session["events"].append(event)
    session["events"] = session["events"][-5000:]
    for name in info.producers:
        session["ephemeral_writes"][name] = {"seq": seq, "ok": ok}
    _save_session(path, session)


def list_cells(path: Path) -> None:
    nb = load_nb(path)
    graph = build_graph(nb.cells)
    states = _cell_statuses(path, nb, graph)
    for idx, cell in enumerate(nb.cells):
        source = cell.get("source", "").strip().replace("\n", " ")
        if len(source) > 92:
            source = source[:89] + "..."
        execution_count = cell.get("execution_count") if cell.cell_type == "code" else None
        state = states.get(idx, {}).get("status", "-")
        print(f"{idx:03d} {cell.cell_type:8s} exec={execution_count!s:>4s} state={state:16s} {source}")


def show_cell(path: Path, index: int) -> None:
    nb = load_nb(path)
    try:
        cell = nb.cells[index]
    except IndexError:
        raise SystemExit(f"Cell index out of range: {index}")
    print(cell.get("source", ""))


def run_cell(path: Path, index: int, timeout: float) -> None:
    nb = load_nb(path)
    try:
        cell = nb.cells[index]
    except IndexError:
        raise SystemExit(f"Cell index out of range: {index}")
    if cell.cell_type != "code":
        raise SystemExit(f"Cell {index} is {cell.cell_type}, not code")
    outputs, execution_count, ok = run_code(path, cell.source, timeout)
    cell.outputs = outputs
    cell.execution_count = execution_count
    save_nb(path, nb)
    _record_cell_execution(path, cell, index, ok)
    if not ok:
        raise SystemExit(1)


def read_stdin_code() -> str:
    if sys.stdin.isatty():
        raise SystemExit("Provide code on stdin, e.g. cnb exec notebook.ipynb <<'PY' ... PY")
    return sys.stdin.read()


def set_cell(path: Path, index: int, run: bool, with_deps: bool, timeout: float) -> None:
    code = read_stdin_code()
    nb = load_nb(path)
    try:
        cell = nb.cells[index]
    except IndexError:
        raise SystemExit(f"Cell index out of range: {index}")
    if cell.cell_type != "code":
        raise SystemExit(f"Cell {index} is {cell.cell_type}, not code")
    cell.source = code
    cell.outputs = []
    cell.execution_count = None
    save_nb(path, nb)
    print(f"updated cell={index}")
    if with_deps:
        run_with_deps(path, index, timeout)
    elif run:
        run_cell(path, index, timeout)


def add_cell(path: Path, after: int | None, run: bool, with_deps: bool, timeout: float) -> None:
    code = read_stdin_code()
    nb = load_nb(path)
    cell = nbformat.v4.new_code_cell(source=code)
    if after is None:
        index = len(nb.cells)
        nb.cells.append(cell)
    else:
        if after < -1 or after >= len(nb.cells):
            raise SystemExit(f"--after out of range: {after}")
        index = after + 1
        nb.cells.insert(index, cell)
    save_nb(path, nb)
    print(f"added cell={index}")
    if with_deps:
        run_with_deps(path, index, timeout)
    elif run:
        run_cell(path, index, timeout)


def exec_ephemeral(path: Path, timeout: float) -> None:
    code = read_stdin_code()
    _, _, ok = run_code(path, code, timeout)
    _record_ephemeral_execution(path, code, ok)
    if not ok:
        raise SystemExit(1)


def vars_cmd(path: Path, timeout: float) -> None:
    code = r'''
import types as _cnb_types
_cnb_rows = []
for _cnb_name, _cnb_value in sorted(globals().items()):
    if _cnb_name.startswith("_") or isinstance(_cnb_value, _cnb_types.ModuleType):
        continue
    try:
        _cnb_repr = repr(_cnb_value).replace("\n", " ")
    except Exception:
        _cnb_repr = "<unreprable>"
    if len(_cnb_repr) > 120:
        _cnb_repr = _cnb_repr[:117] + "..."
    print(f"{_cnb_name:28s} {type(_cnb_value).__name__:20s} {_cnb_repr}")
del _cnb_types, _cnb_rows, _cnb_name, _cnb_value, _cnb_repr
'''
    _, _, ok = run_code(path, code, timeout)
    if not ok:
        raise SystemExit(1)


def _cell_statuses(path: Path, nb, graph: NotebookGraph) -> dict[int, dict[str, Any]]:
    session = _try_load_session(path)
    cell_state = (session or {}).get("cell_state", {})
    memo: dict[int, dict[str, Any]] = {}
    active: set[int] = set()

    def calc(index: int) -> dict[str, Any]:
        if index in memo:
            return memo[index]
        if index in active:
            # Graph edges point backwards, so this should never happen.
            return {"status": "unknown", "reasons": ["dependency-cycle"]}
        active.add(index)
        cell = nb.cells[index]
        rec = cell_state.get(_cell_id(cell))
        reasons: list[str] = []

        if rec is None:
            status_name = "never-run"
            reasons.append("not executed in current kernel")
        elif rec.get("source_hash") != source_hash(cell.get("source", "")):
            status_name = "modified"
            reasons.append("source changed since last execution")
        elif not rec.get("ok", False):
            status_name = "failed"
            reasons.append("last execution failed")
        else:
            status_name = "clean"
            my_seq = int(rec.get("seq", 0))
            for dep in sorted(graph.dependencies.get(index, {})):
                dep_state = calc(dep)
                dep_rec = cell_state.get(_cell_id(nb.cells[dep]))
                if dep_state["status"] != "clean":
                    status_name = "stale-dependency"
                    reasons.append(f"cell {dep} is {dep_state['status']}")
                elif dep_rec and int(dep_rec.get("seq", 0)) > my_seq:
                    status_name = "stale-dependency"
                    syms = ",".join(sorted(graph.dependencies[index][dep]))
                    reasons.append(f"cell {dep} ({syms}) reran after this cell")

        if graph.symbols.get(index) and graph.symbols[index].parse_error:
            reasons.append(f"dependency parser: {graph.symbols[index].parse_error}")

        out = {
            "status": status_name,
            "reasons": reasons,
            "seq": rec.get("seq") if rec else None,
        }
        memo[index] = out
        active.remove(index)
        return out

    for idx in graph.symbols:
        calc(idx)
    return memo


def _id_to_index(nb) -> dict[str, int]:
    return {_cell_id(cell): idx for idx, cell in enumerate(nb.cells) if cell.cell_type == "code"}


def _live_writers(path: Path, nb) -> dict[str, tuple[str, int | str]]:
    session = _try_load_session(path)
    if not session:
        return {}
    id_to_index = _id_to_index(nb)
    writers: dict[str, tuple[str, int | str]] = {}
    # Prefer event history because it preserves the actual execution ordering.
    events = session.get("events", [])
    if events:
        for event in sorted(events, key=lambda e: int(e.get("seq", 0))):
            if event.get("kind") == "cell":
                cid = str(event.get("cell_id", ""))
                idx = id_to_index.get(cid)
                if idx is None:
                    continue
                token: tuple[str, int | str] = ("cell", idx)
            else:
                token = ("exec", int(event.get("seq", 0)))
            for name in event.get("producers", []):
                writers[str(name)] = token
        return writers

    # Backward-compatible fallback for sessions created by v0.1.
    rows: list[tuple[int, int, dict[str, Any]]] = []
    for cid, rec in session.get("cell_state", {}).items():
        idx = id_to_index.get(cid)
        if idx is not None:
            rows.append((int(rec.get("seq", 0)), idx, rec))
    for _, idx, rec in sorted(rows):
        for name in rec.get("producers", rec.get("writes", [])):
            writers[str(name)] = ("cell", idx)
    for name, rec in session.get("ephemeral_writes", {}).items():
        writers[str(name)] = ("exec", int(rec.get("seq", 0)))
    return writers


def deps_cmd(path: Path, index: int | None, as_json: bool) -> None:
    nb = load_nb(path)
    graph = build_graph(nb.cells)
    states = _cell_statuses(path, nb, graph)

    def one(idx: int) -> dict[str, Any]:
        info = graph.symbols[idx]
        return {
            "cell": idx,
            "status": states[idx]["status"],
            "reads": sorted(info.reads),
            "writes": sorted(info.writes),
            "mutations": sorted(info.mutations),
            "dependencies": [
                {"cell": dep, "symbols": sorted(symbols)}
                for dep, symbols in sorted(graph.dependencies.get(idx, {}).items())
            ],
            "dependents": [
                {"cell": dep, "symbols": sorted(symbols)}
                for dep, symbols in sorted(graph.dependents.get(idx, {}).items())
            ],
            "unresolved": sorted(graph.unresolved.get(idx, set())),
            "ancestors": sorted(graph.ancestors(idx)),
            "descendants": sorted(graph.descendants(idx)),
            "parse_error": info.parse_error,
        }

    if index is not None:
        if index not in graph.symbols:
            raise SystemExit(f"Cell {index} is not a code cell or is out of range")
        payload: Any = one(index)
    else:
        payload = [one(idx) for idx in sorted(graph.symbols)]

    if as_json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    rows = [payload] if isinstance(payload, dict) else payload
    for row in rows:
        deps = ", ".join(
            f"{d['cell']}[{','.join(d['symbols'])}]" for d in row["dependencies"]
        ) or "-"
        children = ", ".join(
            f"{d['cell']}[{','.join(d['symbols'])}]" for d in row["dependents"]
        ) or "-"
        unresolved = ",".join(row["unresolved"]) or "-"
        print(
            f"cell {row['cell']:03d} state={row['status']:16s} "
            f"deps={deps} dependents={children} unresolved={unresolved}"
        )
        if index is not None:
            print(f"  reads:     {', '.join(row['reads']) or '-'}")
            print(f"  writes:    {', '.join(row['writes']) or '-'}")
            print(f"  mutations: {', '.join(row['mutations']) or '-'}")
            print(f"  ancestors: {row['ancestors']}")
            print(f"  affected:  {row['descendants']}")
            if row["parse_error"]:
                print(f"  parser:    {row['parse_error']}")


def stale_cmd(path: Path, as_json: bool) -> None:
    nb = load_nb(path)
    graph = build_graph(nb.cells)
    states = _cell_statuses(path, nb, graph)
    payload = [
        {"cell": idx, **states[idx]}
        for idx in sorted(states)
        if states[idx]["status"] != "clean"
    ]
    if as_json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return
    if not payload:
        print("all tracked code cells are clean")
        return
    for row in payload:
        why = "; ".join(row["reasons"])
        print(f"{row['cell']:03d} {row['status']:16s} {why}")


def _plan_for_target(path: Path, target: int) -> tuple[list[int], list[str]]:
    nb = load_nb(path)
    graph = build_graph(nb.cells)
    if target not in graph.symbols:
        raise SystemExit(f"Cell {target} is not a code cell or is out of range")
    states = _cell_statuses(path, nb, graph)
    live = _live_writers(path, nb)
    warnings: list[str] = []
    planned: list[int] = []
    planned_set: set[int] = set()
    visiting: set[int] = set()

    def schedule(idx: int, force: bool = False) -> None:
        if idx in visiting:
            return
        # A clean prerequisite does not need its own dependency chain replayed.
        # Its caller will still verify that the symbols it provides have not
        # been shadowed in the live kernel.
        if idx != target and not force and states[idx]["status"] == "clean":
            return
        visiting.add(idx)

        # First make all declared producers usable. Do this in two passes:
        # scheduling one dependency can itself overwrite a symbol supplied by
        # another dependency, so shadowing must be checked only after all
        # prerequisite repairs have been simulated.
        deps_for_idx = sorted(graph.dependencies.get(idx, {}).items())
        for dep, _symbols in deps_for_idx:
            schedule(dep, force=states[dep]["status"] != "clean")

        for dep, symbols in deps_for_idx:
            expected = ("cell", dep)
            shadowed = [name for name in symbols if live.get(name) != expected]
            if shadowed:
                # A later/out-of-order cell or `cnb exec` overwrote the symbol.
                # Re-execute the intended producer before this consumer.
                schedule(dep, force=True)
                warnings.append(
                    f"restore cell {dep} before {idx}: live writer differs for {','.join(sorted(shadowed))}"
                )

        need = force or idx == target or states[idx]["status"] != "clean"
        if need:
            # If the cell has already been scheduled and still owns all of its
            # outputs in the simulated namespace, another run is unnecessary.
            producers = graph.symbols[idx].producers
            owns_outputs = all(live.get(name) == ("cell", idx) for name in producers)
            if idx not in planned_set or force and not owns_outputs:
                planned.append(idx)
                planned_set.add(idx)
                for name in producers:
                    live[name] = ("cell", idx)

        visiting.remove(idx)

    schedule(target, force=True)

    # Notebook-order execution is the most predictable way to realize a static
    # dependency DAG. Deduplicate while retaining only cells actually needed.
    # If a cell had to be deliberately repeated due to shadowing, preserve that
    # repeat; this is uncommon but semantically meaningful.
    if len(planned) == len(set(planned)):
        planned = sorted(planned)

    for idx in sorted(graph.ancestors(target) | {target}):
        unresolved = graph.unresolved.get(idx, set())
        if unresolved:
            warnings.append(
                f"cell {idx} reads unresolved external names: {','.join(sorted(unresolved))}"
            )
        parse_error = graph.symbols[idx].parse_error
        if parse_error:
            warnings.append(f"cell {idx} dependency analysis incomplete: {parse_error}")

    # Stable de-duplication of warnings.
    warnings = list(dict.fromkeys(warnings))
    return planned, warnings


def plan_cmd(path: Path, target: int, as_json: bool) -> None:
    plan, warnings = _plan_for_target(path, target)
    payload = {"target": target, "run": plan, "warnings": warnings}
    if as_json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return
    print("run: " + (" -> ".join(map(str, plan)) if plan else "nothing"))
    for warning in warnings:
        print(f"warning: {warning}")


def run_with_deps(path: Path, target: int, timeout: float) -> None:
    plan, warnings = _plan_for_target(path, target)
    print("dependency-plan: " + " -> ".join(map(str, plan)))
    for warning in warnings:
        print(f"warning: {warning}")
    for idx in plan:
        print(f"\n[cnb] run cell {idx}")
        run_cell(path, idx, timeout)


def main() -> None:
    parser = argparse.ArgumentParser(prog="cnb", description="Persistent Jupyter notebook control from the terminal")
    sub = parser.add_subparsers(dest="cmd", required=True)

    def p_nb(name: str, help_text: str):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("notebook")
        return p

    p = p_nb("start", "start or reconnect a persistent kernel")
    p.add_argument("--python", dest="kernel_python", help="Python interpreter used for the notebook kernel")
    p_nb("stop", "stop the persistent kernel")
    p_nb("status", "show kernel status")
    p_nb("list", "list notebook cells and live freshness state")

    p = p_nb("show", "print one cell source")
    p.add_argument("index", type=int)

    p = p_nb("run", "run one existing code cell and save its outputs")
    p.add_argument("index", type=int)
    p.add_argument("--deps", action="store_true", help="run the minimal stale dependency plan first")
    p.add_argument("--timeout", type=float, default=3600)

    p = p_nb("set", "replace one code cell from stdin")
    p.add_argument("index", type=int)
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--deps", action="store_true", help="run the minimal dependency plan including this cell")
    p.add_argument("--timeout", type=float, default=3600)

    p = p_nb("add", "append/insert a code cell from stdin")
    p.add_argument("--after", type=int)
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--deps", action="store_true", help="run the minimal dependency plan including this cell")
    p.add_argument("--timeout", type=float, default=3600)

    p = p_nb("exec", "execute stdin in the current kernel without editing the notebook")
    p.add_argument("--timeout", type=float, default=3600)

    p = p_nb("vars", "inspect the current kernel namespace")
    p.add_argument("--timeout", type=float, default=30)

    p = p_nb("deps", "show static symbol dependencies and affected cells")
    p.add_argument("index", type=int, nargs="?")
    p.add_argument("--json", action="store_true")

    p = p_nb("stale", "show cells that are modified, failed, never-run, or dependency-stale")
    p.add_argument("--json", action="store_true")

    p = p_nb("plan", "show the minimal cells to execute before/including a target cell")
    p.add_argument("index", type=int)
    p.add_argument("--json", action="store_true")

    args = parser.parse_args()
    path = _nb_path(args.notebook)

    if args.cmd == "start":
        start(path, args.kernel_python)
    elif args.cmd == "stop":
        stop(path)
    elif args.cmd == "status":
        status(path)
    elif args.cmd == "list":
        list_cells(path)
    elif args.cmd == "show":
        show_cell(path, args.index)
    elif args.cmd == "run":
        if args.deps:
            run_with_deps(path, args.index, args.timeout)
        else:
            run_cell(path, args.index, args.timeout)
    elif args.cmd == "set":
        set_cell(path, args.index, args.run, args.deps, args.timeout)
    elif args.cmd == "add":
        add_cell(path, args.after, args.run, args.deps, args.timeout)
    elif args.cmd == "exec":
        exec_ephemeral(path, args.timeout)
    elif args.cmd == "vars":
        vars_cmd(path, args.timeout)
    elif args.cmd == "deps":
        deps_cmd(path, args.index, args.json)
    elif args.cmd == "stale":
        stale_cmd(path, args.json)
    elif args.cmd == "plan":
        plan_cmd(path, args.index, args.json)


if __name__ == "__main__":
    main()
