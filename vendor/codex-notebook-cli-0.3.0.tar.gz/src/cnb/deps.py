from __future__ import annotations

import ast
import builtins
import hashlib
from dataclasses import dataclass, field
from typing import Iterable

try:
    from IPython.core.inputtransformer2 import TransformerManager
except Exception:  # pragma: no cover - IPython is pulled in by ipykernel
    TransformerManager = None  # type: ignore[assignment]


IGNORED_NAMES = set(dir(builtins)) | {
    "get_ipython",
    "__name__",
    "__file__",
    "__package__",
    "__builtins__",
}

# Methods that very commonly mutate their receiver. This is intentionally
# conservative but avoids treating every read-only method call as a write.
MUTATING_METHODS = {
    "add", "append", "backward", "clear", "discard", "extend", "fit",
    "fit_transform", "insert", "load_state_dict", "partial_fit", "pop",
    "popitem", "remove", "reverse", "setdefault", "sort", "step", "train",
    "update", "zero_grad",
}


@dataclass
class CellSymbols:
    reads: set[str] = field(default_factory=set)
    writes: set[str] = field(default_factory=set)
    mutations: set[str] = field(default_factory=set)
    parse_error: str | None = None

    @property
    def producers(self) -> set[str]:
        return self.writes | self.mutations


@dataclass
class NotebookGraph:
    symbols: dict[int, CellSymbols]
    dependencies: dict[int, dict[int, set[str]]]
    dependents: dict[int, dict[int, set[str]]]
    unresolved: dict[int, set[str]]

    def ancestors(self, index: int) -> set[int]:
        seen: set[int] = set()
        stack = list(self.dependencies.get(index, {}))
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            stack.extend(self.dependencies.get(cur, {}))
        return seen

    def descendants(self, index: int) -> set[int]:
        seen: set[int] = set()
        stack = list(self.dependents.get(index, {}))
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            stack.extend(self.dependents.get(cur, {}))
        return seen


def source_hash(source: str) -> str:
    return hashlib.sha256(source.encode("utf-8")).hexdigest()[:16]


def _root_name(node: ast.AST) -> str | None:
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def _target_names(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, (ast.Tuple, ast.List)):
        out: set[str] = set()
        for elt in node.elts:
            out |= _target_names(elt)
        return out
    return set()


def _target_mutations(node: ast.AST) -> set[str]:
    if isinstance(node, (ast.Attribute, ast.Subscript)):
        root = _root_name(node)
        return {root} if root else set()
    if isinstance(node, (ast.Tuple, ast.List)):
        out: set[str] = set()
        for elt in node.elts:
            out |= _target_mutations(elt)
        return out
    return set()


class _RuntimeReadVisitor(ast.NodeVisitor):
    """Collect names read while evaluating an expression now.

    Function/lambda bodies are not evaluated at definition time, so only their
    defaults/decorators/annotations are considered by the statement analyzer.
    """

    def __init__(self) -> None:
        self.reads: set[str] = set()

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load) and node.id not in IGNORED_NAMES:
            self.reads.add(node.id)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        # Defaults do not exist on Lambda AST arguments in a separately useful
        # way here; visit defaults but not body.
        for default in (*node.args.defaults, *node.args.kw_defaults):
            if default is not None:
                self.visit(default)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:  # pragma: no cover
        return

    visit_AsyncFunctionDef = visit_FunctionDef


def _expr_reads(node: ast.AST | None) -> set[str]:
    if node is None:
        return set()
    v = _RuntimeReadVisitor()
    v.visit(node)
    return v.reads


class _MutationVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.names: set[str] = set()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        return

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_Lambda(self, node: ast.Lambda) -> None:
        return

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Attribute):
            method = node.func.attr
            inplace_true = any(
                kw.arg == "inplace" and isinstance(kw.value, ast.Constant) and kw.value.value is True
                for kw in node.keywords
            )
            if method in MUTATING_METHODS or inplace_true:
                root = _root_name(node.func.value)
                if root:
                    self.names.add(root)
        self.generic_visit(node)


def _mutation_roots(node: ast.AST | None) -> set[str]:
    if node is None:
        return set()
    v = _MutationVisitor()
    v.visit(node)
    return v.names


def _function_body_global_reads(node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    """Conservative globals referenced by a function body.

    Python resolves globals at call time, so rerunning the function definition is
    not strictly required when one of these changes. Tracking the dependency is
    nevertheless useful for an agent: callers of the function become transitively
    stale instead of silently depending on hidden global state.
    """
    local_names = {
        arg.arg
        for arg in (
            *node.args.posonlyargs,
            *node.args.args,
            *node.args.kwonlyargs,
            *([node.args.vararg] if node.args.vararg else []),
            *([node.args.kwarg] if node.args.kwarg else []),
        )
    }
    global_names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Global):
            global_names.update(child.names)
        elif isinstance(child, ast.Name) and isinstance(child.ctx, (ast.Store, ast.Del)):
            local_names.add(child.id)
        elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and child is not node:
            local_names.add(child.name)
        elif isinstance(child, (ast.Import, ast.ImportFrom)):
            for alias in child.names:
                if isinstance(child, ast.Import):
                    local_names.add(alias.asname or alias.name.split(".")[0])
                elif alias.name != "*":
                    local_names.add(alias.asname or alias.name)

    reads: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            if child.id in IGNORED_NAMES:
                continue
            if child.id not in local_names or child.id in global_names:
                reads.add(child.id)
    return reads


def _function_definition_reads(node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    reads: set[str] = set()
    for d in node.decorator_list:
        reads |= _expr_reads(d)
    for d in (*node.args.defaults, *node.args.kw_defaults):
        if d is not None:
            reads |= _expr_reads(d)
    if node.returns:
        reads |= _expr_reads(node.returns)
    for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs):
        if arg.annotation:
            reads |= _expr_reads(arg.annotation)
    if node.args.vararg and node.args.vararg.annotation:
        reads |= _expr_reads(node.args.vararg.annotation)
    if node.args.kwarg and node.args.kwarg.annotation:
        reads |= _expr_reads(node.args.kwarg.annotation)
    reads |= _function_body_global_reads(node)
    return reads


def _transform_source(source: str) -> str:
    if TransformerManager is None:
        return source
    try:
        return TransformerManager().transform_cell(source)
    except Exception:
        return source


def analyze_source(source: str) -> CellSymbols:
    result = CellSymbols()
    try:
        tree = ast.parse(_transform_source(source))
    except SyntaxError as exc:
        result.parse_error = f"{exc.msg} (line {exc.lineno})"
        return result

    defined: set[str] = set()

    def add_reads(names: Iterable[str]) -> None:
        for name in names:
            if name not in defined and name not in IGNORED_NAMES:
                result.reads.add(name)

    def analyze_stmt(stmt: ast.stmt) -> None:
        nonlocal defined

        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            add_reads(_function_definition_reads(stmt))
            result.writes.add(stmt.name)
            defined.add(stmt.name)
            return

        if isinstance(stmt, ast.ClassDef):
            for d in stmt.decorator_list:
                add_reads(_expr_reads(d))
            for base in stmt.bases:
                add_reads(_expr_reads(base))
            for kw in stmt.keywords:
                add_reads(_expr_reads(kw.value))
            # Class bodies execute immediately. Analyze them conservatively as
            # reads, but class-local stores are not module-level writes.
            for child in stmt.body:
                for node in ast.walk(child):
                    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                        add_reads({node.id})
            result.writes.add(stmt.name)
            defined.add(stmt.name)
            return

        if isinstance(stmt, (ast.Import, ast.ImportFrom)):
            names: set[str] = set()
            if isinstance(stmt, ast.Import):
                for alias in stmt.names:
                    names.add(alias.asname or alias.name.split(".")[0])
            else:
                for alias in stmt.names:
                    if alias.name != "*":
                        names.add(alias.asname or alias.name)
            result.writes |= names
            defined |= names
            return

        mutating_calls = _mutation_roots(stmt)
        if mutating_calls:
            add_reads(mutating_calls)
            result.mutations |= mutating_calls

        if isinstance(stmt, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
            value = getattr(stmt, "value", None)
            # AugAssign reads its target before writing it.
            if isinstance(stmt, ast.AugAssign):
                add_reads(_expr_reads(stmt.target))
            add_reads(_expr_reads(value))
            for target in targets:
                names = _target_names(target)
                muts = _target_mutations(target)
                if muts:
                    add_reads(muts)
                    result.mutations |= muts
                result.writes |= names
                defined |= names
            return

        if isinstance(stmt, (ast.For, ast.AsyncFor)):
            add_reads(_expr_reads(stmt.iter))
            names = _target_names(stmt.target)
            muts = _target_mutations(stmt.target)
            result.writes |= names
            result.mutations |= muts
            defined |= names
            for child in stmt.body:
                analyze_stmt(child)
            for child in stmt.orelse:
                analyze_stmt(child)
            return

        if isinstance(stmt, (ast.With, ast.AsyncWith)):
            for item in stmt.items:
                add_reads(_expr_reads(item.context_expr))
                if item.optional_vars:
                    names = _target_names(item.optional_vars)
                    result.writes |= names
                    defined |= names
            for child in stmt.body:
                analyze_stmt(child)
            return

        if isinstance(stmt, ast.If):
            add_reads(_expr_reads(stmt.test))
            # Branch-sensitive dataflow is overkill here. Analyze both branches
            # conservatively and union their writes.
            before = set(defined)
            writes_before = set(result.writes)
            for child in stmt.body:
                analyze_stmt(child)
            body_defined = set(defined)
            defined = set(before)
            for child in stmt.orelse:
                analyze_stmt(child)
            else_defined = set(defined)
            defined = before | (body_defined & else_defined)
            result.writes |= writes_before
            return

        if isinstance(stmt, (ast.While,)):
            add_reads(_expr_reads(stmt.test))
            for child in stmt.body:
                analyze_stmt(child)
            for child in stmt.orelse:
                analyze_stmt(child)
            return

        if isinstance(stmt, ast.Try):
            for child in stmt.body:
                analyze_stmt(child)
            for handler in stmt.handlers:
                if handler.type:
                    add_reads(_expr_reads(handler.type))
                if handler.name:
                    result.writes.add(handler.name)
                    defined.add(handler.name)
                for child in handler.body:
                    analyze_stmt(child)
            for child in stmt.orelse:
                analyze_stmt(child)
            for child in stmt.finalbody:
                analyze_stmt(child)
            return

        if isinstance(stmt, ast.Delete):
            for target in stmt.targets:
                names = _target_names(target)
                muts = _target_mutations(target)
                add_reads(names | muts)
                result.mutations |= names | muts
            return

        # Generic expression/runtime reads.
        add_reads(_expr_reads(stmt))

        # Walrus operators are writes in the surrounding scope.
        for node in ast.walk(stmt):
            if isinstance(node, ast.NamedExpr):
                names = _target_names(node.target)
                result.writes |= names
                defined |= names

    for stmt in tree.body:
        analyze_stmt(stmt)

    result.reads -= IGNORED_NAMES
    return result


def build_graph(cells: list) -> NotebookGraph:
    symbols: dict[int, CellSymbols] = {}
    dependencies: dict[int, dict[int, set[str]]] = {}
    dependents: dict[int, dict[int, set[str]]] = {}
    unresolved: dict[int, set[str]] = {}
    latest_writer: dict[str, int] = {}

    for idx, cell in enumerate(cells):
        if getattr(cell, "cell_type", None) != "code":
            continue
        info = analyze_source(cell.get("source", ""))
        symbols[idx] = info
        dependencies[idx] = {}
        unresolved[idx] = set()

        for name in sorted(info.reads):
            producer = latest_writer.get(name)
            if producer is None:
                unresolved[idx].add(name)
            else:
                dependencies[idx].setdefault(producer, set()).add(name)
                dependents.setdefault(producer, {}).setdefault(idx, set()).add(name)

        for name in sorted(info.producers):
            latest_writer[name] = idx

    for idx in symbols:
        dependents.setdefault(idx, {})

    return NotebookGraph(symbols, dependencies, dependents, unresolved)
