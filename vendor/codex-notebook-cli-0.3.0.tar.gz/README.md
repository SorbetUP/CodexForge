# codex-notebook-cli (`cnb`)

`cnb` lets a terminal coding agent use a real Jupyter notebook incrementally while keeping one Python kernel alive between terminal commands.

The key split is:

- the `.ipynb` file stores cells and outputs;
- the Jupyter kernel stores live Python state (`df`, loaded models, imports, caches, GPU objects, etc.);
- each `cnb ...` invocation reconnects to that same kernel;
- `cnb` tracks which notebook cells were executed in the **current** kernel and builds a symbol-level dependency graph between cells.

The result is close to how a human uses Jupyter: inspect, change one cell, execute only what became invalid, inspect the result, iterate.

## Install

```bash
cd codex-notebook-cli
python -m pip install -e .
```

Requires Python 3.10+. The CLI can live in an isolated environment while the persistent kernel runs with the project Python selected via `--python`, `CNB_KERNEL_PYTHON`, an active `VIRTUAL_ENV`, or an auto-detected `.venv`/`venv`.

## Basic workflow

```bash
# Start one persistent kernel for the notebook.
cnb start experiment.ipynb
# Or force the project interpreter:
# cnb start experiment.ipynb --python .venv/bin/python

# Inspect notebook + live freshness state.
cnb list experiment.ipynb
cnb vars experiment.ipynb

# Execute an existing cell only.
cnb run experiment.ipynb 4

# Replace cell 4 and execute only that cell.
cnb set experiment.ipynb 4 --run <<'PY'
features = build_features(df, version=3)
print(features.shape)
PY

# Temporary probe: executes in the same kernel but is not added to the notebook.
cnb exec experiment.ipynb <<'PY'
print(df.shape)
print(type(model))
PY

cnb stop experiment.ipynb
```

## Dependency-aware mode

Version 0.2 adds static symbol dependencies plus live execution tracking.

### Inspect dependencies

```bash
cnb deps experiment.ipynb 12
```

Example:

```text
cell 012 state=clean            deps=7[df], 10[model] dependents=15[preds] unresolved=-
  reads:     df, model
  writes:    preds
  mutations: -
  ancestors: [2, 7, 8, 10]
  affected:  [15, 16]
```

`cnb` analyzes Python names read and written by each cell. It also recognizes common in-place mutations such as:

- `df["x"] = ...`
- `x.append(...)`
- `model.fit(...)`
- `optimizer.step()`
- operations using `inplace=True`

Function bodies are conservatively linked to globals they reference, so hidden dependencies such as a function reading a global `df` are not silently lost.

Machine-readable output is available with:

```bash
cnb deps experiment.ipynb 12 --json
```

### See invalidated cells

```bash
cnb stale experiment.ipynb
```

The live state distinguishes:

- `never-run`: not executed in the current kernel;
- `modified`: source changed since its last execution;
- `failed`: its last execution failed;
- `stale-dependency`: one of its upstream producers changed or reran later;
- `clean`: consistent with the tracked execution history.

The state is tied to the current kernel session. Starting a fresh kernel correctly makes every code cell `never-run`, even if old execution counts remain stored in the `.ipynb` file.

### Ask for a minimal execution plan

```bash
cnb plan experiment.ipynb 18
```

Example:

```text
run: 7 -> 12 -> 18
```

Only stale prerequisites needed for cell 18 are selected.

`cnb plan` also detects a classic out-of-order Jupyter hazard. Suppose cell 2 defines `df`, cell 7 consumes it, but a later cell or temporary `cnb exec` overwrote `df` in the live kernel. The plan restores the intended producer before executing the consumer:

```text
run: 2 -> 7
warning: restore cell 2 before 7: live writer differs for df
```

This is why the planner tracks both the static notebook graph and the actual order in which the current kernel was mutated.

### Execute the plan

After inspecting it:

```bash
cnb run experiment.ipynb 18 --deps
```

or modify a cell and immediately repair its required upstream state:

```bash
cnb set experiment.ipynb 18 --deps <<'PY'
score = evaluate(model, features, threshold=0.42)
score
PY
```

Likewise for a newly inserted cell:

```bash
cnb add experiment.ipynb --after 18 --deps <<'PY'
worst = find_worst_cases(score)
worst.head(20)
PY
```

For expensive ML notebooks, prefer `cnb plan` first. `--deps` deliberately executes the proposed cells and can therefore retrigger training or preprocessing if those cells are genuinely stale.

## Suggested Codex workflow

Put `AGENTS.example.md` (or its relevant section) into your repository as `AGENTS.md`.

A useful task prompt then becomes:

> Work incrementally in `analysis.ipynb`. Reuse its persistent kernel through `cnb`. Inspect `cnb status`, `cnb list`, `cnb stale`, and `cnb deps` before changing expensive cells. Use `cnb plan` to determine the smallest required replay. Do not restart or run the whole notebook unless clean reproducibility validation is actually required.

A good iteration loop is:

```text
cnb status
    ↓
cnb list / cnb vars
    ↓
cnb deps <target>
    ↓
edit one cell
    ↓
cnb stale
    ↓
cnb plan <target>
    ↓
inspect expensive/destructive cells in the plan
    ↓
cnb run <target> --deps
    ↓
inspect outputs and iterate
```

## Why this is better than a plain Python REPL

A REPL keeps objects alive, but it does not know the structure of your notebook. `cnb` keeps both:

1. **live state** in the persistent Jupyter kernel;
2. **durable source/output** in the `.ipynb`;
3. **dependency state** between cells;
4. **execution history** for the current kernel.

That means an agent can operate incrementally without pretending the notebook is a linear script on every turn.

## Important semantics

This deliberately allows human-style out-of-order execution. The live kernel can therefore differ from a clean top-to-bottom run. `cnb plan` reduces that risk for tracked symbols, but static analysis cannot prove arbitrary Python side effects.

For final validation of an experiment, a clean restart + top-to-bottom execution remains the reference for reproducibility.

## Current limitations

- Python/ipykernel only.
- Dependency inference is static and conservative; arbitrary dynamic behavior (`exec`, reflection, hidden I/O state, monkey patching, native extensions) cannot be fully inferred.
- `cnb exec` writes are tracked when their written/mutated Python names can be inferred, but external side effects are not reversible.
- Rich binary outputs are stored in the notebook; terminal output focuses on textual representations.
- A kernel session is local to the machine and disappears when the process/machine dies.
- No multi-agent locking yet; avoid concurrent writers on the same notebook.

## Commands

```text
cnb start NB [--python PATH]
cnb stop NB
cnb status NB
cnb list NB
cnb show NB INDEX
cnb run NB INDEX [--deps]
cnb set NB INDEX [--run | --deps] < code.py
cnb add NB [--after INDEX] [--run | --deps] < code.py
cnb exec NB < code.py
cnb vars NB
cnb deps NB [INDEX] [--json]
cnb stale NB [--json]
cnb plan NB INDEX [--json]
```
